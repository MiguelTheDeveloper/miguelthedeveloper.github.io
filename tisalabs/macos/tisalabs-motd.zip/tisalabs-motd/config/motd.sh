#!/bin/bash


echo "
                                                                                   
$(tput setaf 5)        //                                                                     
$(tput setaf 5)     ./   $(tput setaf 6)    ,(////////(*                                                    
$(tput setaf 5)    /.   $(tput setaf 6)  .///////////////\\\\\\                                                
$(tput setaf 5)   /,   $(tput setaf 6)  ///////   .//////*  *                                               
$(tput setaf 5)  */    $(tput setaf 6)  /// $(tput sgr0) __      $(tput setaf 6)  ///*                                                 
$(tput setaf 5)  //      $(tput sgr0)    /  \   $(tput setaf 6)      //                                                 
$(tput setaf 5)  *//      $(tput sgr0)   \__/      $(tput setaf 6)   */.                                                
$(tput setaf 5)   ////           ,///  $(tput setaf 6)   ./                                                 
$(tput setaf 5)    ///////    ///////  $(tput setaf 6)   //                                                 
$(tput setaf 5)  //////////////////   $(tput setaf 6)   (/                                                  
$(tput setaf 5)      ///////////.     $(tput setaf 6) ./                                                    
$(tput setaf 5)                     $(tput setaf 6) /,                                                      
$(tput sgr0)
  _______ _           _           _         
 |__   __(_)         | |         | |        
    | |   _ ___  __ _| |     __ _| |__  ___ 
    | |  | / __|/ _\` | |    / _\` | '_ \/ __|
    | |  | \__ \ (_| | |___| (_| | |_) \__ \\
    |_|  |_|___/\__,_|______\__,_|_.__/|___/
                                            
$(tput sgr0)"