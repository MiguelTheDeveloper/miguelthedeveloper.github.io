
BASHRC=/etc/zshrc
sudo cp ./config/motd.sh /etc/

if ! grep -rq "bash /etc/motd.sh" "$BASHRC";
then
 cat ./config/motdappend>>$BASHRC
fi
