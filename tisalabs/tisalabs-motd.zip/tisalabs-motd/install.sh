
BASHRC=/etc/bash.bashrc
sudo cp ./config/motd.sh /etc/

if ! grep -rq "bash /etc/motd.sh" "$BASHRC";
then
 cat ./config/motdappend>>$BASHRC
fi
