FILE=/etc/motd.sh
if test -f "$FILE"; then
  rm /etc/motd.sh
fi
